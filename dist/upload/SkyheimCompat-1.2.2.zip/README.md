# Skyheim Compat

**Required companion for Skyheim 1.0 Fix**  
by **cjayride**

---

## Important Credit & Disclaimer

**This is NOT an original mod.**

All credit for Skyheim goes to the original developer **makail** (also known as Makzimus).

- Original mod: [Skyheim by makail on Thunderstore](https://thunderstore.io/c/valheim/p/makail/Skyheim/)
- Original Nexus page: [Skyheim on Nexus Mods](https://www.nexusmods.com/valheim/mods/916)

This is a **companion plugin** for **Skyheim 1.0 Fix**. It is not Skyheim by itself and will not work without the Fix package (`skyheim.dll`).

If makail ever releases an official update, **please switch back to the original mod** and remove both this companion and Skyheim 1.0 Fix.

---

### Latest Update (1.2.2)

- Rune Altar name follows the translation file in the hammer menu and in the world. It is listed under Misc.

### Previous (1.2.1)

- Windfury proc VFX and hit sound play on female characters as well as male.

### Previous (1.2.0)

- Paired release with Skyheim Fix 1.4.0: altar/imbue fixes, Ukrainian and editable translations, SeneaL chest + imbue, Epic Loot armor imbue, healing rune balance and tooltips.

### Previous (1.1.36)

- Healing rune tooltip lists 10-yard range and predicted \"Heals for X over Y\" from Nature Magic and quality.

### Previous (1.1.35)

- Rune of Healing: Nature Magic increases how much you heal; rune quality increases how long the HoT lasts.

### Previous (1.1.33)

- Enchanted Epic Loot set pieces (Ragnar, unique legendaries, etc.) can be Eitr-imbued. Close the chest to start.

### Previous (1.1.32)

- Runic Chest subtitle keeps the shard cost instead of falling back to SeneaL's slot count.
- Closing the chest starts the imbue when using SeneaL UI.

### Previous (1.1.31)

- Rune recipes craft only at the Rune Altar. The altar itself still opens as an imbue chest.
- The Runic Chest hover text shows how to imbue armor and where to craft runes.
- Altar shard counting matches Eitr Shards by name as well as prefab.

### Previous (1.1.30)

- Ukrainian is in, thanks to a community contribution. All three language blocks (English, Polish, Ukrainian) carry the full set of Skyheim strings, so the mod follows the game's language setting.
- Drop an edited `skyheim.json` next to `skyheim.dll` to change wording or add a language. The loose file wins over the one packed inside the mod.
- A language with no block yet falls back to English words instead of showing blanks.
- Less per-frame UI work: the cooldown overlay on hotbar and inventory slots is cached after the first find.

### Previous (1.1.29)

- Returning to the character select after disconnect no longer duplicates Skyheim items in ObjectDB.

### Previous (1.1.28)

- Tested on Valheim 1.0.21. No behavior changes.

### Previous (1.1.27)

- Rune cooldown timers show on the vanilla hotbar and in the inventory. SeneaL slots already showed them.

### Latest Update (1.1.26)

- Each Skyheim spell sound has a volume slider. The default is half of the original volume. Immolation still plays one explosion per tick.

### Latest Update (1.1.25)

- Rune of Recall returns to the bed after the world has autosaved, instead of the last logout point.
- Skyheim names stay in the selected language. Later item wakes no longer write the English text back over them.

### Latest Update (1.1.24)

- The Rune Altar status line says how many Eitr Shards the armor needs, how many are in the chest, and how long the imbue takes. The timer still starts only when the full amount is there and the chest is closed.
- With SeneaL UI, that line is the chest subtitle. A Fenris Coat with 12 shards reads "Need 35, have 12, 5 min".
- After an imbue finishes, it says "Finished adding Eitr" while that piece is still in the chest. Opening it later with an imbued piece says "Item already imbued".
- The status line updates when the chest contents change, when the timer second changes, or once when an imbue finishes.

### Latest Update (1.1.19)

- If the Rune of Healing area misses its caster, the caster still receives the heal.

### Latest Update (1.1.18)

- Rune of Healing is a configurable heal-over-time (default about 36 HP at quality 1, over 8 seconds).
- Heal and Warmth area radii are configurable. Skyheim's sizes are 5 m and 30 m.
- Immolation aura hits no longer build Epic Loot Eikthyr Shocking Charge, and the explosion sound can be scaled down.
- The Rune Altar can eitr-imbue Epic Loot enchanted armor, plus OdinHorse cloth armor and the Horse Trophy Helmet.

### Latest Update (1.1.15)

- Rune cooldown timers show on the hotbar and in the inventory.
- Stops the null-reference spam from Skyheim updating a cooldown image that was already destroyed.

### Latest Update (1.1.10)

- Fixed a console NullReferenceException from Skyheim when poison/AoE damage ticks (windfury damage hook).

### Latest Update (1.1.9)

- Thunderstore package uses the 1.0 COMPAT icon.

### 1.1.8

- Draws Skyheim rune cooldown seconds on SeneaL hotbar, action, and inventory slots without replacing SeneaL's HUD prefabs.
- If SeneaL UI is not installed, Skyheim keeps its original vanilla hotbar and inventory cooldown overlays.

### 1.1.7

- Stops Skyheim from rewriting the vanilla hotbar/inventory slot prefabs when SeneaL UI is installed, so food, action bar, and minimap can display.

### 1.1.5

- Fixed a stack-overflow crash when hovering enchanted armor in a chest.
- Inventory descriptions are populated directly at pointer-enter, before Valheim tries to show the tooltip.

### 1.1.1

- Fixed item names and descriptions in-game (no more missing/blank localization).
- Fixed a crash that occurred when trying to craft items (including with `devcommands`).
- Added configuration files for all the runes (`BepInEx/config/cjayride.skyheimcompat.cfg` after you load a world once).
- Enforces rune cooldown blocking on current Valheim.

---

## Installation

### Thunderstore / r2modman / Gale

Install **Skyheim 1.0 Fix**. This Compat package is pulled in as a dependency.

Do **not** also enable original **makail-Skyheim**. That DLL fails on Valheim 1.0 (`TypeLoadException` / `Element`) and all runes vanish.

### Manual / Nexus

1. Install **BepInEx**.
2. Install **Skyheim 1.0 Fix 1.3.24**.
3. Install this **Skyheim Compat 1.1.10** package into `BepInEx/plugins`.
4. Launch the game.

Do **not** use this with the original (unfixed) Skyheim.

---

## Notes

- This is a temporary community fix.
- Report issues with this fix to **cjayride**.

Thank you to **makail** for creating Skyheim.  
— cjayride
